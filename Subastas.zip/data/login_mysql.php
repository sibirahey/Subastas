<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
define("NOMBRE_HOST", "localhost");// Nombre del host
define("BASE_DE_DATOS", "subastas_db"); // Nombre de la base de modelos
define("USUARIO", "subastas_usr"); // Nombre del usuario
define("CONTRASENA", "sub4st4s_m41n*"); // Constraseña