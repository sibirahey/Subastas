
$( document ).ready(function() {
    $( ".mainFooter" ).load( "footer.html", function() {
  		console.log( "Load was performed." );
	});
});
