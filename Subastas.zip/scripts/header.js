
$( document ).ready(function() {
    $( ".mainHeader" ).load( "header.html", function() {
  		console.log( "Load was performed." );
	});
});
